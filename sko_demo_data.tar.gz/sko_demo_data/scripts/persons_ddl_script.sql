create database if not exists personal_data;

drop table if exists personal_data.persons;
create external table if not exists personal_data.persons(
        name string,
        ssn string,
        dob string,
        email string,
        ip string,
        phone string,
        credit_card string,
	Germany_IBAN string,
	UK_IBAN string,
	Finland_IBAN string,
	Portugal_IBAN string,
	Sweden_IBAN string,
	Norway_IBAN string,
	Switzerland_IBAN string,
	Poland_IBAN string,
	Ireland_IBAN string,
	Latvia_IBAN string,
	Estonia_IBAN string,
	Bulgaria_IBAN string,
	Ireland_Passport string,
	Finland_Passport string,
	Italy_Passport string,
	Germany_Passport string,
	Belgium_Passport string,
	France_Passport string,
	Sweden_National_Id string,
	Bulgaria_National_Id string,
	Latvia_National_Id string,
	Estonia_National_Id string,
	Poland_National_id string,
	Iceland_National_Id string,
	Lithuania_National_Id string,
	Finland_National_id string,
	Italy_National_Id string,
	Greece_National_Id string
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LOCATION '${LOCATION}/personal_data/persons'
