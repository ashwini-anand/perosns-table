#!/bin/sh
set -e
SCRIPTPATH=$( cd $(dirname $0) ; pwd -P )
DEMO_DATA_ROOT_DIR=${SCRIPTPATH}/..
echo "Creating HDFS directories..."
su - hdfs -c "hdfs dfs -mkdir -p /user/admin && hdfs dfs -chown admin /user/admin"
su - hdfs -c "hdfs dfs -mkdir -p /personal_data/structured"
echo "Copying data to HDFS..."
su - hdfs -c "hdfs dfs -put ${DEMO_DATA_ROOT_DIR}/structured/* /personal_data/structured/"
echo "Setting ownership..."
su - hdfs -c "hdfs dfs -chown -R admin /personal_data/structured/persons"
echo "Setting hive data..."
beeline -u jdbc:hive2://localhost:10000/default -n admin -p admin -f ${DEMO_DATA_ROOT_DIR}/scripts/persons_ddl_script.sql
echo "Verifying hive data..."
echo "count(persons)..."
beeline -u jdbc:hive2://localhost:10000/default -n admin -p admin -e "select count(*) from personal_data.persons;"
